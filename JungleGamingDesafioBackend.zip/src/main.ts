import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);

  app.setGlobalPrefix("api/v1");

  const port = Number(Bun.env.PORT ?? 3000);
  await app.listen(port, "0.0.0.0", () => {
    console.info(`Api rodando na porta ${port}`);
  });
}

bootstrap();
